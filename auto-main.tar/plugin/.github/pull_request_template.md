## Problem and change

<!-- Explain the problem, resulting behavior, affected components, and related issue if one exists. -->
<!-- Use "Closes #123" only if this PR fully resolves that issue. -->

## Validation

<!-- Record exact commands and results: ./gradlew build test spotlessCheck and plugin load checks on the named SoulFire version. -->
<!-- Include relevant versions, reproduction observations, or screenshots. Remove credentials and private data. -->
<!-- Explain any checks that you could not run. -->

## Compatibility and follow-up

<!-- Describe API, protocol, configuration, permissions, or packaging changes and migration steps. -->
<!-- State "None" if there are no compatibility changes or known limitations. -->

## Ready for review

- [ ] The change has a focused scope and a Conventional Commit title.
- [ ] I recorded validation results and added targeted tests for changed logic where practical.
- [ ] Documentation, examples, and generated files are updated, or no update is needed.
