# Support for SoulFirePluginExample

## Questions and reports

Start with the [SoulFire documentation](https://soulfiremc.com/docs).
For setup and usage questions, ask in the [Discord community](https://soulfiremc.com/discord).
For contribution setup, builds, and checks, read [CONTRIBUTING.md](CONTRIBUTING.md).

For example plugin reports, include the example revision, SoulFire version, Java version, and the failed build task or plugin load step.
Share reproduction steps and relevant text logs. Remove tokens, passwords, account data, proxy credentials, and bypass keys first.

Search [open and closed issues](https://github.com/soulfiremc-com/SoulFirePluginExample/issues) before opening a report.
Add new reproduction details to an existing issue for the same problem.
Otherwise, use the [issue chooser](https://github.com/soulfiremc-com/SoulFirePluginExample/issues/new/choose).

## Find the right project

Use this repository for example plugin.
Use [SoulFire](https://github.com/soulfiremc-com/SoulFire/issues) for server, bot, protocol, or SDK problems.
Use [SoulFireClient](https://github.com/soulfiremc-com/SoulFireClient/issues) for desktop and browser client problems.
Use [soulfiremc.com](https://github.com/soulfiremc-com/soulfiremc.com/issues) for published documentation and website problems.
The [organization support directory](https://github.com/soulfiremc-com/.github/blob/main/SUPPORT.md) lists every project.

## Private reports

Report vulnerabilities through the [security policy](https://github.com/soulfiremc-com/.github/blob/main/SECURITY.md).
Report community concerns through the [code of conduct](https://github.com/soulfiremc-com/.github/blob/main/CODE_OF_CONDUCT.md).
Do not include private details in a public issue.
